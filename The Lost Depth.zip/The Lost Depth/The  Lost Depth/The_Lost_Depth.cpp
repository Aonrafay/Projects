#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>

using namespace std;

void slowPrint(const string& text, int delayMilliseconds = 20) {
    for (char c : text) {
        cout << c << flush;
        this_thread::sleep_for(chrono::milliseconds(delayMilliseconds));
    }
    cout << endl;
}

void ClearScreen() {
    system("CLS");
}

void loading() {
    cout << "\033[32m"; 
    for (int i = 0; i <= 52; i++) {
        cout << char(178) << flush;
        this_thread::sleep_for(chrono::milliseconds(200));
    }
    cout << "\033[0m" << endl; 
}

const int MAX_TUNNEL_PROGRESS = 100;
const int MAX_TUNNEL_STABILITY = 100;
const int MAX_STAMINA = 100;

class Hazard {
public:
    static int generateDamage() {
        return (rand() % 10 + 5); 
    }

    static bool occurs() {
        return (rand() % 100 < 50); 
    }

    static string description() {
        string hazards[] = {
            "Toxic gas leak!",
            "Cave-in tremors!",
            "Giant underground bug attack!",
            "Falling debris!"
        };
        return hazards[rand() % 4];
    }
};

class TunnelSystem {
public:

    int stability = MAX_TUNNEL_STABILITY;
    int progress = 0;

    void explore() {
        int gain = rand() % 15 + 5;
        progress += gain;
        if (progress > MAX_TUNNEL_PROGRESS) progress = MAX_TUNNEL_PROGRESS;
        slowPrint("You explored deeper into the tunnel and made " + to_string(gain) + "% progress.");
    }

    void reinforce() {
        int repair = rand() % 15 + 10;
        stability += repair;
        if (stability > MAX_TUNNEL_STABILITY) stability = MAX_TUNNEL_STABILITY;
        slowPrint("You reinforced the tunnel and restored " + to_string(repair) + "% stability.");
    }

    void takeDamage(int amount) {
        stability -= amount;
        if (stability < 0) stability = 0;
        slowPrint("Hazard caused " + to_string(amount) + "% damage to tunnel stability!");
    }

    bool isStable() {
        return stability > 0;
    }

    bool isEscaped() {
        return progress >= MAX_TUNNEL_PROGRESS;
    }
};

class Player {
public:
    int stamina = MAX_STAMINA;
    bool alive = true;

    void rest() {
        int regain = rand() % 15 + 10;
        stamina += regain;
        if (stamina > MAX_STAMINA) stamina = MAX_STAMINA;
        slowPrint("You rested and regained " + to_string(regain) + "% stamina.");
    }

    void reduceStamina(int amount) {
        stamina -= amount;
        if (stamina < 0) stamina = 0;
    }

    void handleHazard(TunnelSystem& tunnel) {
        if (Hazard::occurs()) {
            string desc = Hazard::description();
            int damage = Hazard::generateDamage();
            slowPrint("[HAZARD] " + desc);
            tunnel.takeDamage(damage);
        }
    }

    bool isExhausted() {
        return stamina <= 0;
    }
};

class Game {
private:
    TunnelSystem tunnel;
    Player player;
    bool running = true;

public:
    void start() {
        srand(static_cast<unsigned int>(time(0)));

        intro();

        while (running) {
            ClearScreen();
            statusReport();
            displayMenu();
            int choice;
            cout << "Choose your action: ";
            cin >> choice;
            handleChoice(choice);
            this_thread::sleep_for(chrono::milliseconds(700));

            if (player.isExhausted()) {
                slowPrint("[FAILURE] You collapsed from exhaustion in the tunnel...");
                running = false;
            }
            else if (!tunnel.isStable()) {
                slowPrint("[FAILURE] The tunnel collapsed, burying you alive...");
                running = false;
            }
            else if (tunnel.isEscaped()) {
                slowPrint("[SUCCESS] You found an exit and escaped the underground world!");
                running = false;
            }
        }

        endReport();
    }

    void intro() {
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        slowPrint("\t\t\t      \033[33m___________.__             .__                  __    ________                 __  .__     \033[0m", 1);
        slowPrint("\t\t\t      \033[33m\\__    ___/|  |__   ____   |  |   ____  _______/  |_  \\______ \\   ____ _______/  |_|  |__  \033[0m", 1);
        slowPrint("\t\t\t      \033[33m  |    |   |  |  \\_/ __ \\  |  |  /  _ \\/  ___/\\   __\\  |    |  \\_/ __ \\\\____ \\   __\\  |  \\ \033[0m", 1);
        slowPrint("\t\t\t      \033[33m  |    |   |   Y  \\  ___/  |  |_(  <_> )___ \\  |  |    |    `   \\  ___/|  |_> >  | |   Y  \\ \033[0m", 1);
        slowPrint("\t\t\t      \033[33m  |____|   |___|  /\\___  > |____/\\____/____  > |__|   /_______  /\\___  >   __/|__| |___|  / \033[0m", 1);
        slowPrint("\t\t\t      \033[33m                \\/     \\/                  \\/                 \\/     \\/|__|             \\/ \033[0m", 1);
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << "\t\t\t\t\t\t";
        loading(); 
        cout << endl;
        cout << endl;
        cout << endl;
        cout << endl;
        cout << "\t\t\t\t\t\t";
        cout << "   \033[33mDeveloped by Abdul Rehman, Hashir, Aaon, Hassan\033[0m" << endl;
        this_thread::sleep_for(chrono::seconds(4s));
        ClearScreen();
        slowPrint("\n=== UNDERGROUND WORLD ADVENTURE ===", 30);
        slowPrint("You awaken deep inside a collapsed mining system.");
        slowPrint("You must explore and find a way out while staying alive...");
        slowPrint("Press Enter to begin...");
        cin.ignore();
        cin.get();
    }


    void statusReport() {
        slowPrint("========== STATUS ==========");
        cout << "Tunnel Progress:   " << tunnel.progress << "% / " << MAX_TUNNEL_PROGRESS << "%" << endl;
        cout << "Tunnel Stability:  " << tunnel.stability << "% / " << MAX_TUNNEL_STABILITY << "%" << endl;
        cout << "Player Stamina:    " << player.stamina << "% / " << MAX_STAMINA << "%" << endl;
        cout << "===========================" << endl;
    }

    void displayMenu() {
        slowPrint("======= ACTIONS =======");
        slowPrint("1. Explore Tunnel");
        slowPrint("2. Reinforce Tunnel");
        slowPrint("3. Rest");
        slowPrint("4. Wait & Handle Hazard");
        slowPrint("5. Give Up");
        slowPrint("=======================");
    }

    void handleChoice(int choice) {
        ClearScreen();
        switch (choice) {
        case 1:
            tunnel.explore();
            player.reduceStamina(10);
            break;
        case 2:
            tunnel.reinforce();
            player.reduceStamina(8);
            break;
        case 3:
            player.rest();
            break;
        case 4:
            player.handleHazard(tunnel);
            player.reduceStamina(5);
            break;
        case 5:
            slowPrint("You sit down and give up... The darkness takes you.");
            running = false;
            break;
        default:
            slowPrint("[Invalid input] You hesitated and lost valuable time.");
            player.reduceStamina(5);
            break;
        }

        player.reduceStamina(5);

        if (rand() % 100 < 40) {
            player.handleHazard(tunnel);
        }
    }

    void endReport() {
        slowPrint("\n==== MISSION REPORT ====");
        if (tunnel.isEscaped()) {
            slowPrint("[SUCCESS] You escaped the underground tunnels alive!");
        }
        else if (!tunnel.isStable()) {
            slowPrint("[FAILURE] The tunnel collapsed...");
        }
        else if (player.isExhausted()) {
            slowPrint("[FAILURE] You died from exhaustion...");
        }
        else {
            slowPrint("[FAILURE] You gave up.");
        }
    }
};

int main() {
    cin.get();
    Game adventure;
    adventure.start();
    return 0;
}